Run commands:

Go to microhobby folder, it consists of converter_mh_to_html/reset_remove_active.py, converter_mh_to_html.py, microhobby/code1.mh. index.html is the output with active blink numbers for LEDs.

C:\Users\Mitesh Khadgi\Downloads\python_examples\microhobby>python converter_mh_to_html/reset_remove_active.py

index.html reset to no active option

C:\Users\Mitesh Khadgi\Downloads\python_examples\microhobby>notepad index.html

C:\Users\Mitesh Khadgi\Downloads\python_examples\microhobby>python converter_mh_to_html/converter_mh_to_html.py

index.html reset to no active option
blink = 1;
['blink', '=', '1']
index.html modified with respect to blink = 1
blink = 4;
['blink', '=', '4']
index.html modified with respect to blink = 4
Number of lines executed:  2

C:\Users\Mitesh Khadgi\Downloads\python_examples\microhobby>notepad index.html

C:\Users\Mitesh Khadgi\Downloads\python_examples\microhobby>